const express = require("express");
const router = express.Router();

const { cart, orders } = require("../data/store");

// Place an order
router.post("/", (req, res) => {
    if (cart.length === 0) {
        return res.status(400).json({
            message: "Cart is empty"
        });
    }

    const total = cart.reduce(
        (sum, item) => sum + item.price * item.quantity,
        0
    );

    const order = {
        id: Date.now(),
        items: cart.map(item => ({ ...item })),
        total: total,
        status: "Placed",
        date: new Date()
    };

    orders.push(order);

    // Clear cart after placing the order
    cart.length = 0;

    res.status(201).json({
        message: "Order placed successfully",
        order
    });
});

// Get order history
router.get("/", (req, res) => {
    res.status(200).json(orders);
});

module.exports = router;