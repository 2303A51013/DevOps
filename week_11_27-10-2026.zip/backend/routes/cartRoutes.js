const express = require("express");
const router = express.Router();

const products = require("../data/products");
const { cart } = require("../data/store");

// Add product to cart
router.post("/", (req, res) => {
    const { productId, quantity } = req.body;

    const product = products.find(
        p => p.id === Number(productId)
    );

    if (!product) {
        return res.status(404).json({
            message: "Product not found"
        });
    }

    if (!Number.isInteger(quantity) || quantity < 1) {
        return res.status(400).json({
            message: "Quantity must be a positive integer"
        });
    }

    const existingItem = cart.find(
        item => item.productId === product.id
    );

    if (existingItem) {
        existingItem.quantity += quantity;

        return res.status(201).json({
            message: "Cart quantity increased",
            item: existingItem
        });
    }

    const cartItem = {
        id: Date.now(),
        productId: product.id,
        name: product.name,
        price: product.price,
        quantity: quantity
    };

    cart.push(cartItem);

    res.status(201).json({
        message: "Product added to cart",
        item: cartItem
    });
});

// Update cart quantity
router.put("/:id", (req, res) => {
    const { quantity } = req.body;

    if (!Number.isInteger(quantity) || quantity < 1) {
        return res.status(400).json({
            message: "Quantity must be a positive integer"
        });
    }

    const item = cart.find(
        item => item.id === Number(req.params.id)
    );

    if (!item) {
        return res.status(404).json({
            message: "Cart item not found"
        });
    }

    item.quantity = quantity;

    res.status(200).json({
        message: "Cart quantity updated",
        item
    });
});

// Remove item from cart
router.delete("/:id", (req, res) => {
    const index = cart.findIndex(
        item => item.id === Number(req.params.id)
    );

    if (index === -1) {
        return res.status(404).json({
            message: "Cart item not found"
        });
    }

    cart.splice(index, 1);

    res.status(200).json({
        message: "Item removed from cart"
    });
});

module.exports = router;