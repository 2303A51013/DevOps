const express = require("express");
const router = express.Router();

const products = require("../data/products");

// Get all products
router.get("/", (req, res) => {
    res.status(200).json(products);
});

// Get product by ID
router.get("/:id", (req, res) => {
    const product = products.find(
        p => p.id === Number(req.params.id)
    );

    if (!product) {
        return res.status(404).json({
            message: "Product not found"
        });
    }

    res.status(200).json(product);
});

module.exports = router;