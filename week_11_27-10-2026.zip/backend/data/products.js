const products = [
    {
        id: 101,
        name: "Laptop",
        price: 60000,
        description: "High-performance laptop"
    },
    {
        id: 102,
        name: "Mobile Phone",
        price: 25000,
        description: "Latest smartphone"
    },
    {
        id: 103,
        name: "Headphones",
        price: 2000,
        description: "Wireless headphones"
    },
    {
        id: 104,
        name: "Keyboard",
        price: 1500,
        description: "Mechanical keyboard"
    }
];

module.exports = products;