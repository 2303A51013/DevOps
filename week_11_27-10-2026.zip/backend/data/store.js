const cart = [];
const orders = [];

module.exports = {
    cart,
    orders
};