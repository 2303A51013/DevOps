
const foods = require("../data/foods");

let orders = [];
let nextOrderId = 1;

function getOrders(req, res) {
  res.status(200).json(orders);
}

function createOrder(req, res) {
  const { customerName, address, phone, items } = req.body;

  const orderItems = [];

  for (const item of items) {
    const food = foods.find(
      (foodItem) => foodItem.id === item.id
    );

    if (!food) {
      return res.status(400).json({
        message: `Food item with ID ${item.id} not found.`
      });
    }

    orderItems.push({
      id: food.id,
      name: food.name,
      price: food.price,
      quantity: item.quantity
    });
  }

  const total = orderItems.reduce(
    (sum, item) => sum + item.price * item.quantity,
    0
  );

  const order = {
    id: nextOrderId++,
    customerName,
    address,
    phone,
    items: orderItems,
    total,
    status: "Placed"
  };

  orders.push(order);

  res.status(201).json({
    message: "Order placed successfully.",
    order
  });
}

module.exports = {
  getOrders,
  createOrder
};
