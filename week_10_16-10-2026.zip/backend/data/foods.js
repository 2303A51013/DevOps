
const foods = [
  {
    id: 1,
    name: "Chicken Biryani",
    restaurantId: 1,
    price: 220,
    description: "Delicious chicken biryani with aromatic spices."
  },
  {
    id: 2,
    name: "Veg Biryani",
    restaurantId: 1,
    price: 160,
    description: "Fresh vegetables cooked with basmati rice."
  },
  {
    id: 3,
    name: "Margherita Pizza",
    restaurantId: 2,
    price: 199,
    description: "Classic pizza with cheese and tomato."
  },
  {
    id: 4,
    name: "Cheese Burger",
    restaurantId: 3,
    price: 149,
    description: "Juicy burger with cheese and fresh vegetables."
  },
  {
    id: 5,
    name: "Chocolate Cake",
    restaurantId: 4,
    price: 120,
    description: "Rich and delicious chocolate cake."
  }
];

module.exports = foods;
