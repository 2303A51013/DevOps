
const restaurants = [
  {
    id: 1,
    name: "Spice Garden",
    cuisine: "Indian, Biryani",
    rating: 4.5,
    time: "25-30 min"
  },
  {
    id: 2,
    name: "Pizza Palace",
    cuisine: "Pizza, Italian",
    rating: 4.3,
    time: "30-35 min"
  },
  {
    id: 3,
    name: "Burger House",
    cuisine: "Burgers, Fast Food",
    rating: 4.6,
    time: "20-25 min"
  },
  {
    id: 4,
    name: "Sweet Treats",
    cuisine: "Desserts, Ice Cream",
    rating: 4.4,
    time: "15-20 min"
  }
];

module.exports = restaurants;
