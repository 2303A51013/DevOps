
const request = require("supertest");
const app = require("../server");

describe("Food Delivery Backend API Tests", () => {

  // Test 1: Restaurant API
  describe("GET /api/restaurants", () => {
    test("Should return all restaurants", async () => {
      const response = await request(app)
        .get("/api/restaurants");

      expect(response.statusCode).toBe(200);
      expect(response.body).toHaveLength(4);
      expect(response.body[0].name).toBe("Spice Garden");
    });
  });

  // Test 2: Food API
  describe("GET /api/foods", () => {
    test("Should return all food items", async () => {
      const response = await request(app)
        .get("/api/foods");

      expect(response.statusCode).toBe(200);
      expect(response.body).toHaveLength(5);
      expect(response.body[0].name).toBe("Chicken Biryani");
    });
  });

  // Test 3: Order API
  describe("POST /api/orders", () => {
    test("Should successfully create a new order", async () => {
      const orderData = {
        customerName: "Siddarth",
        address: "Warangal",
        phone: "9876543210",
        items: [
          {
            id: 1,
            quantity: 2
          }
        ]
      };

      const response = await request(app)
        .post("/api/orders")
        .send(orderData);

      expect(response.statusCode).toBe(201);
      expect(response.body.message).toBe(
        "Order placed successfully."
      );
      expect(response.body.order.total).toBe(440);
      expect(response.body.order.status).toBe("Placed");
    });

    test("Should return all placed orders", async () => {
      const response = await request(app)
        .get("/api/orders");

      expect(response.statusCode).toBe(200);
      expect(Array.isArray(response.body)).toBe(true);
      expect(response.body.length).toBeGreaterThan(0);
    });
  });

  // Test 4: Order Validation
  describe("Order Validation", () => {
    test("Should reject an empty customer name", async () => {
      const response = await request(app)
        .post("/api/orders")
        .send({
          customerName: "",
          address: "Warangal",
          phone: "9876543210",
          items: [{ id: 1, quantity: 1 }]
        });

      expect(response.statusCode).toBe(400);
      expect(response.body.message).toBe(
        "Customer name is required."
      );
    });

    test("Should reject an invalid phone number", async () => {
      const response = await request(app)
        .post("/api/orders")
        .send({
          customerName: "Siddarth",
          address: "Warangal",
          phone: "12345",
          items: [{ id: 1, quantity: 1 }]
        });

      expect(response.statusCode).toBe(400);
      expect(response.body.message).toBe(
        "Enter a valid 10-digit phone number."
      );
    });

    test("Should reject an empty order", async () => {
      const response = await request(app)
        .post("/api/orders")
        .send({
          customerName: "Siddarth",
          address: "Warangal",
          phone: "9876543210",
          items: []
        });

      expect(response.statusCode).toBe(400);
      expect(response.body.message).toBe(
        "Order must contain at least one food item."
      );
    });

    test("Should reject an invalid food ID", async () => {
      const response = await request(app)
        .post("/api/orders")
        .send({
          customerName: "Siddarth",
          address: "Warangal",
          phone: "9876543210",
          items: [{ id: 999, quantity: 1 }]
        });

      expect(response.statusCode).toBe(400);
      expect(response.body.message).toContain(
        "not found"
      );
    });

    test("Should reject zero quantity", async () => {
      const response = await request(app)
        .post("/api/orders")
        .send({
          customerName: "Siddarth",
          address: "Warangal",
          phone: "9876543210",
          items: [{ id: 1, quantity: 0 }]
        });

      expect(response.statusCode).toBe(400);
      expect(response.body.message).toBe(
        "Invalid food item or quantity."
      );
    });
  });
});
