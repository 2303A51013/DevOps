
const express = require("express");
const router = express.Router();

const {
  getOrders,
  createOrder
} = require("../controllers/orderController");

const validateOrder = require("../middleware/validateOrder");

router.get("/", getOrders);

router.post("/", validateOrder, createOrder);

module.exports = router;
