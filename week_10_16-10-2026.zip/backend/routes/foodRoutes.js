
const express = require("express");
const router = express.Router();

const foods = require("../data/foods");

router.get("/", (req, res) => {
  res.status(200).json(foods);
});

module.exports = router;
