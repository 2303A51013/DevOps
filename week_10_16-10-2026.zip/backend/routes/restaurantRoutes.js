
const express = require("express");
const router = express.Router();

const restaurants = require("../data/restaurants");

router.get("/", (req, res) => {
  res.status(200).json(restaurants);
});

module.exports = router;
