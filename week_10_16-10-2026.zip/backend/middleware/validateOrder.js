
function validateOrder(req, res, next) {
  const { customerName, address, phone, items } = req.body;

  if (
    !customerName ||
    typeof customerName !== "string" ||
    !customerName.trim()
  ) {
    return res.status(400).json({
      message: "Customer name is required."
    });
  }

  if (
    !address ||
    typeof address !== "string" ||
    !address.trim()
  ) {
    return res.status(400).json({
      message: "Delivery address is required."
    });
  }

  if (!/^[0-9]{10}$/.test(phone || "")) {
    return res.status(400).json({
      message: "Enter a valid 10-digit phone number."
    });
  }

  if (!Array.isArray(items) || items.length === 0) {
    return res.status(400).json({
      message: "Order must contain at least one food item."
    });
  }

  const validItems = items.every(
    (item) =>
      Number.isInteger(item.id) &&
      Number.isInteger(item.quantity) &&
      item.quantity > 0
  );

  if (!validItems) {
    return res.status(400).json({
      message: "Invalid food item or quantity."
    });
  }

  next();
}

module.exports = validateOrder;
